﻿// MIS 3013 005
// Jan 24, 2024
// Andrea Hernandez
// 113552217

// comments
Console.WriteLine("Second lecture");//
// Writeline: function
// WriteLine() :function call

// statement

// 1. RAM memory
// 2. CPU

// datatype
// datatype_name variable_name;
// resources:
// 1. simple, not expensive,: int double bool char 
// 2. complex, expensive,

// 1. letter number _
// 2. start with letter or _ (could not start with number)
int age1;//
// age1 variable name; instance object
// int is the roomtype
// age1 is int, simple, not expensive
int age2;// int simple not expensive

double weight1;// double simple, not expensive
double weight2;

// int 4 Byte
// double 8 Byte
bool b1;// b1 bool simple not expensive
bool b2; //true false 1 bit = 1/8 Byte

char c1;// c1 char simple not expensive 2 byte

// hard topics
// 1. assignment
// 2. functions
// 3. simple vs complex

// assignment
// = assignment operator
age1 = 20;
// assignment statement
//
age1 = 22;//
// assignment
//
weight1 = 30 * 2 + 20.0 / 4;// assignment
// expression
Console.WriteLine(weight1);


